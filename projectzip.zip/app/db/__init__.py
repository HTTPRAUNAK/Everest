"""SQLite persistence layer."""
